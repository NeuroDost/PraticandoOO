package mundoDoAutomovel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

public class Carro {

	ArrayList<String> cadastroCarro = new ArrayList<String>();

	private String placa;
	private String marca;
	private String modelo;
	private int ano;
	private String dono;
	private float valor;

	public Carro() {
	}

	public Carro(String placa, String marca, String modelo, int ano, String dono, float valor) {
		this.placa = placa;
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.dono = dono;
		this.valor = valor;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		cadastroCarro.add(placa);
		this.placa = placa;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		cadastroCarro.add(marca);
		this.marca = marca;

	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Collection<? extends String> registroCarro(String modelo) {
		Scanner dados = new Scanner(System.in);
		Scanner dados1 = new Scanner(System.in);
		Scanner dados2 = new Scanner(System.in);
		Scanner dados3 = new Scanner(System.in);
		Scanner dados4 = new Scanner(System.in);
		Scanner dados5 = new Scanner(System.in);
		Scanner dados6 = new Scanner(System.in);
		int i = 0;
		System.out.println("Registre até 4 carros.");
		do {
			System.out.println("placa do carro:");
			placa = dados.next();

			System.out.println("marca do carro:");
			marca = dados1.next();

			System.out.println("modelo do carro:");
			modelo = dados2.next();

			System.out.println("dono do carro");
			dono = dados4.next();

			System.out.println("valor do carro:");
			valor = dados5.nextFloat();
		} while (i < 4);
		return cadastroCarro;

	}

	public int getAno() {
		return ano;
	}

	// public void setAno(Int ano) {
	// cadastroCarro.add(ano);
	// this.ano = ano;
//}
	public String getDono() {
		return dono;
	}

	public void setDono(String dono) {
		this.dono = dono;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public void pesquisarCarro() {
		System.out.println();
	}

}
