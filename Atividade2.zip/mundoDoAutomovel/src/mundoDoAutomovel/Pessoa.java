package mundoDoAutomovel;

public class Pessoa {

	private String nome;
	private String cpf;
	private String telefone;

	public Pessoa(String nome, String cpf, String telefone) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
	}

	public Pessoa() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void getNome() {
		System.out.println("===========O proprietario da loja se chama William Nassau===========");
		System.out.println("===========A loja existe desde 1995===========");
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void getCpf() {
		System.out.println("===========O cpf do próprietario é 12343454343===========");
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public void getTelefone() {
		System.out.println("===========Para entrar em contato e mais informações sobre a loja e veículos ligue:/n"
				+ "99898989===========");
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	};

}
