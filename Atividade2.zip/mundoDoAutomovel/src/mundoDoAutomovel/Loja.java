package mundoDoAutomovel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Loja {

	public static void main(String[] args) {
		ArrayList<String> carros = new ArrayList();

		carros.add("Renault Kwid;$22222");
		carros.add("Fiat Mobi;$70000");
		carros.add("Renault Sandero;$75031");
		carros.add("Renault Logan;$79619");
		carros.add("Volkswagen Gol G;$89365");
		Pessoa W = new Pessoa();

		int[] arr = new int[] { 22222, 700000, 75031, 79619, 89365 };

		Scanner dados6 = new Scanner(System.in);
		Scanner dados2 = new Scanner(System.in);
		Scanner dados4 = new Scanner(System.in);
		Carro c1 = new Carro();

		String placa = "";
		String marca = "";
		String modelo = "";
		int ano = 0;
		String dono = "";
		float valor = 0;

		System.out.println("1-Cadastrar carro" + "\n2 - listagem de carros" + "\n3 - pesquisar carro pelo modelo"
				+ "\n4 - valor de carros em ordem crescente" + "\n5- Informações sobre proprietario"
				+ "\n6 - Escolha o seu próximo carro" + "\n7 - aperte 7 para encerrar");

		boolean parada = true;

		while (parada) {

			int escolha = dados6.nextInt();
			switch (escolha) {
			case 1:
				c1.registroCarro(modelo);
				carros.addAll(c1.registroCarro(modelo));

				break;

			case 2:
				for (String i : carros) {
					System.out.println(i);
				}

				break;
			case 3:
				// nao consigo fazet meu if funcioanar, como faria??
				System.out.println("Para pesquisar um carro insira o modelo:");
				modelo = dados2.next();
				if (carros.contains(modelo)) {
					System.out.println("Carro:" + modelo + "disponível em estoque");
				} else {
					System.out.println("Carro não esta disponivel em estoque");
				}
				break;

			case 4:
				for (int i : arr) {
					System.out.println(i + "");
					Arrays.sort(arr);
				}
				break;

			case 5:
				W.getNome();
				W.getCpf();
				W.getTelefone();

				break;

			case 6:
				int y;
				System.out.println("Adquirir um carro da lista para isso informe a posiçao a posição:");
				y = dados4.nextInt();
				carros.remove(y);
				break;
			case 7:

				parada = false;
				System.out.println("Encerrado!");
				break;
			}

		}

	}

}
