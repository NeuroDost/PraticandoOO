package mundoDoAutomovel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nomes;
		String[] nomesDelimitados;//utilizada para armanezar nomes recebidos pelo método split
		Scanner scanner = new Scanner(System.in);
		
		//Recebe os nomes delimitados
		System.out.println("Digite os nomes dos jogadores delimitados por ',':");
		nomes = scanner.next();
		//Inicializa um array de strings com o valor da variável nomes 
		nomesDelimitados=nomes.split(",");
		
		ArrayList<String> nomesArrayList = new ArrayList<>();
		
		//Adiciona nomesDelimatados no ArrayList
		for (int i = 0; i < nomesDelimitados.length; i++) {
			String nome=nomesDelimitados[i];
			nomesArrayList.add(nome);
		}
		
		
		System.out.println(nomesArrayList.size());
		

		System.out.print("            TIME 1 \n ");
		System.out.println("______________________________ \n");
		
		Collections.shuffle(nomesArrayList);
		
		//Realiza um laço até o tamanho do ArrayList
		//No código anterior o laço sempre acessava uma posição inexistente no ArrayList 
		for (int i = 0; i <nomesArrayList.size(); i++) {
			//Realiza o cast do resultado da expressão( Math.random() * nomesArrayList.size()
			//No código anterior, o cast era feito apenas em Math.random()
			int escolha = (int)( Math.random() * nomesArrayList.size());
			System.out.println("*" + nomesArrayList.get(escolha));
			nomesArrayList.remove(escolha);

		}

		System.out.print("            TIME 2 \n ");
		System.out.println("______________________________ \n");

		Collections.shuffle(nomesArrayList);

		//Realiza um laço até o tamanho do ArrayList
		for (int i = 0; i < nomesArrayList.size(); i++) {
			int escolha = (int) Math.random() * nomesArrayList.size();
			System.out.println("*" + nomesArrayList.get(escolha));
			nomesArrayList.remove(escolha);
	}

}
}